if (CKEDITOR && SCF && SCF.fieldManagers && SCF.fieldManagers.ckeditor) {
	CKEDITOR.config.extraPlugins = 'codesnippet,';
	CKEDITOR.allowedContent = true;

	var addedToolbar = { name: 'custom', items: [ 'CodeSnippet']};
	SCF.fieldManagers.ckeditor.prototype.config.toolbar.push(addedToolbar);	
}
