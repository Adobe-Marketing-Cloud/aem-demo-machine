
jQuery(function ($) {
    var groups = {"": []};
    var groupRename = {
        "": "<em>none</em>"
    };

    $("[data-group]").each(function () {
        var groupElem = $(this);
        var groupName = groupElem.data("group") || "";
        if (typeof groups[groupName] == "undefined") {
			groups[groupName] = [groupElem];
        } else {
            groups[groupName].push(groupElem);
        }
    });

    var groupSwitcher = $(".groups");
    var groupList = groupSwitcher.find(".group-list");
    $.each(groups, function(groupName, groupComponents) {
        if (groupName in groupRename) {
			groupName = groupRename[groupName];
        }
        $("<label><input type='checkbox' checked='checked'/>"+groupName+"</label>")
        	.appendTo(groupList)
        	.find("input").on("change", function () {
                var inputElem = $(this);
                var isVisible = inputElem.is(':checked');
                for (var i = 0; i < groupComponents.length; i++) {
                    groupComponents[i].toggle(isVisible);
                }
            });
    });

    $("#check-all").on("change", function () {
		var inputElem = $(this);
        
    });
});
