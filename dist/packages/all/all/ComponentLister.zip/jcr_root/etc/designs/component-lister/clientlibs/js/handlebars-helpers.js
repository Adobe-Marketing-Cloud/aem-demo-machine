
(function($) {
    
    Handlebars.registerHelper("getResourceType", helpers.getResourceType);

    Handlebars.registerHelper("getTitle", function(path) {
        if ("properties" in this && "jcr:title" in this.properties) {
            return this.properties["jcr:title"];
        } else {
            return path.split("/").pop();
        }
    });

    Handlebars.registerHelper("ifNotEmpty", function(obj, options) {
        if ($.isEmptyObject(obj)) {
            return options.inverse(this);
        } else {
            return options.fn(this);
        }
    });

    Handlebars.registerHelper("compare", function (lvalue, operator, rvalue, options) {
        var operators = {
            "==":     	  function (l, r) { return l == r; },
            "===":    	  function (l, r) { return l === r; },
            "!=":  	  	  function (l, r) { return l != r; },
            "!==":    	  function (l, r) { return l !== r; },
            "<":      	  function (l, r) { return l < r; },
            ">":      	  function (l, r) { return l > r; },
            "<=":     	  function (l, r) { return l <= r; },
            ">=":     	  function (l, r) { return l >= r; }
        };
    
        if (options === undefined) {
            options = rvalue;
            rvalue = operator;
            operator = "===";
        }
        if (operators[operator](lvalue, rvalue)) {
            return options.fn(this);
        } else {
            return options.inverse(this);
        }
    });

    Handlebars.registerHelper("hasChildren", function (obj, options) {
        if ((obj instanceof Object) && !(obj instanceof Array)) {
            return options.fn(this);
        } else {
            return options.inverse(this);
        }
    });

    var recursiveTemplate;
    Handlebars.registerHelper("getChildren", function(obj, options) {
      	if (options.fn !== undefined) {
      		recursiveTemplate = options.fn;
      	}
    	var out = "";
        for (var o in obj) {
            out += recursiveTemplate(obj[o], { data: { key: o } });
        }
      	return out;
    });

})(jQuery);
