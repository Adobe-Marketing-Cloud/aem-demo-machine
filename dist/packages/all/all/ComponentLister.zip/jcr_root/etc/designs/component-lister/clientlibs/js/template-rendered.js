

jQuery(function ($) {
    function initGroups(components) {
        var groups = {};
        components.find("li[data-group]").each(function () {
            var element = $(this);
            var groupName = element.data("group");
            if (groupName in groups) {
                groups[groupName].push(element);
            } else {
                groups[groupName] = [element];
            }
        });

        var template = Handlebars.compile($("#groups-template").html());
        $(".config-groups")
        	.html(template({ groups: helpers.sortObject(groups) }))
        	.find(".group-list").delegate("input", "change", function () {
                var input = $(this);
                var toggle = input.prop("checked");
                var group = groups[input.attr("name")];
                for (var i = group.length-1; i >= 0; --i) {
                    group[i].toggle(toggle);
                }
        	});

        $("#check-all").on("change", function () {
            var input = $(this);
            $(".group-list input").prop("checked", input.prop("checked")).trigger("change");
        });
    }

    function initDetails(components) {
        $(".config-details")
            .delegate("input", "change", function () {
                var input = $(this);
                var name  = input.attr("name");
                components.addClass(name+"-"+input.val());
                input.closest("li").find("input:not(:checked)").each(function() {
                    components.removeClass(name+"-"+$(this).attr("value"));
                });
            })
	        .find("input:checked").trigger("change");

        components.delegate(".details h4 span", "click", function () {
            var detailsSection = $(this).closest("section");
            var componentsSection = detailsSection.parent().closest("section");
            var detailsClass = detailsSection.attr("class").split(" ")[0];
            if (componentsSection.is("."+detailsClass+"-fold")) {
				detailsSection.toggleClass("toggle-fold");
            } else if (componentsSection.is("."+detailsClass+"-show")) {
				detailsSection.toggleClass("toggle-show");
            }
        });
    }

    $("body").on("template-rendered", function () {
        var components = $(".components");
		initGroups(components);
        initDetails(components);
    });
});
