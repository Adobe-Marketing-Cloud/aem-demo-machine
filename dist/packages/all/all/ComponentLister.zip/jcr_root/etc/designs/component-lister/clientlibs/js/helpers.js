
var helpers = { components: null };

helpers.setComponents = function (components) {
    helpers.components = components;

    // Compute list of overlays for each component
    for (var c in components) {
        var component = components[c];
        if ("properties" in component && "sling:resourceSuperType" in component.properties) {
            var sup = components[helpers.getResourceType(component.properties["sling:resourceSuperType"])];
            if ("overlays" in sup) {
                sup.overlays.push(c);
            } else {
                sup.overlays = [c];
            }
        }
    }
};

helpers.getResourceType = function (resourceType) {
    if (helpers.components !== null) {
        if (resourceType[0] !== "/") {
            if ("/apps/"+resourceType in helpers.components) {
                return "/apps/"+resourceType;
            } else if ("/libs/"+resourceType in helpers.components) {
                return "/libs/"+resourceType;
            }
        }
        return resourceType;
    } else {
        return null;
    }
};

helpers.sortObject = function (oldObj) {
    var keys = Object.keys(oldObj).sort();
    var keysLength = keys.length;
    var newObj = {};
    for (var i = 0; i < keysLength; ++i) {
        var key = keys[i];
        newObj[key] = oldObj[key];
    }
	return newObj;
};
