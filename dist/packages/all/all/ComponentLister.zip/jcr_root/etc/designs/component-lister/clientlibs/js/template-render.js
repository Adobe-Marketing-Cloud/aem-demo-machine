
jQuery(function ($) {
    $.getJSON("/content/component-lister.json", function(data) {
        helpers.setComponents(data);
        var template = Handlebars.compile($("#components-template").html());
        $(".components").html(template({ components: helpers.components }));
		$("body").trigger("template-rendered").addClass("rendered");
    });
});
